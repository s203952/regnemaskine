package com.company;
import java.util.Scanner;
public class Main {
  static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {

        while (true) {
            String a = input.nextLine();
            switch (a) {
                case("dog"):
                    System.out.println("woof!");
                    break;
                case("cat"):
                    System.out.println("meow");
                    break;
                case("fish"):
                    System.out.println("Blop");
                    break;
                case("cow"):
                    System.out.println("muuhuhuhhh");
                    break;
                case("lion"):
                    System.out.println("MEEAAAAOOWWW");
                    break;
                case("sheep"):
                    System.out.println("baaaah");
                    break;
                case("duck"):
                    System.out.println("quack");
                    break;
                default:
                    System.out.println("i dont know this animal");
            }
        }
    }
}
